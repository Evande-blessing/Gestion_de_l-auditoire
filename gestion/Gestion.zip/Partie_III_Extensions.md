# Derniere partie - Rechargement, affichage et extensions

## Q5. Rechargement et affichage du planning

Les fonctions demandees sont dans `fonctions.php` :

```php
function charger_planning(?string $chemin_fichier = null): array
function afficher_planning_html(array $planning): string
```

`charger_planning` lit `planning.json` par defaut. Elle peut aussi lire `planning.txt` si le chemin donne se termine par `.txt`.

`afficher_planning_html` construit un tableau hebdomadaire avec les jours en colonnes et les creneaux en lignes. Chaque case affiche le cours, le groupe et la salle.

## Q6. Script principal

Le fichier `index.php` orchestre le systeme :

- chargement des salles, promotions, cours, options et planning ;
- affichage de messages de succes ou d'erreur ;
- generation automatique du planning ;
- sauvegarde dans `planning.json` et `planning.txt` ;
- affichage du planning hebdomadaire ;
- acces aux extensions : conflits, rapport d'occupation, modification manuelle.

## B1. Detection de conflits

La fonction suivante analyse `planning.txt` :

```php
function detecter_conflits_planning_txt(string $chemin_fichier): array
```

Elle detecte :

- une meme salle utilisee sur deux affectations simultanees ;
- un meme groupe place sur deux cours simultanes.

## B2. Rapport d'occupation

La fonction suivante genere `rapport_occupation.txt` :

```php
function generer_rapport_occupation(array $planning, array $salles, array $creneaux_disponibles, string $chemin_fichier): bool
```

Le rapport contient pour chaque salle :

- le nombre de creneaux occupes ;
- le nombre de creneaux libres ;
- le taux d'occupation.

## B3. Mise a jour manuelle du planning

La fonction suivante modifie une affectation dans `planning.txt` :

```php
function modifier_affectation_planning_txt(...)
```

Avant l'ecriture, elle verifie la capacite de la salle, la disponibilite de la salle et la disponibilite du groupe.

## B4. Formulaires HTML/PHP de saisie

Les formulaires existent dans `admin.php` pour saisir ou modifier :

- les salles ;
- les promotions ;
- les cours.

Apres chaque modification, le systeme sauvegarde les donnees dans les fichiers JSON et produit aussi des copies CSV :

- `data/salles.csv` ;
- `data/promotions.csv` ;
- `data/cours.csv`.
