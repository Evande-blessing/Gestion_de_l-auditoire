# Partie II - Implementation PHP procedurale

## Q5. Lecture des fichiers de donnees

Les fonctions de lecture se trouvent dans `fonctions.php` :

```php
function charger_salles(?string $chemin_fichier = null): array
function charger_promotions(?string $chemin_fichier = null): array
function charger_cours(?string $chemin_fichier = null): array
function charger_options(?string $chemin_fichier = null): array
```

Chaque fonction charge un fichier JSON dans un tableau associatif PHP. Le parametre `$chemin_fichier` permet de lire un autre fichier que celui par defaut.

Les erreurs gerees sont :

- fichier introuvable ;
- fichier vide ou illisible ;
- JSON malforme ;
- ligne malformee ;
- champ obligatoire manquant ;
- valeur numerique invalide pour les champs comme `capacite`, `effectif` et `volume_horaire`.

Les messages d'erreur sont conserves dans `$GLOBALS['erreurs_chargement']` et peuvent etre recuperes avec :

```php
function erreurs_chargement(): array
```

## Q6. Verification des contraintes

Les fonctions de validation sont :

```php
function salle_disponible(array $planning, string $id_salle, $creneau): bool
function capacite_suffisante(array $salles, string $id_salle, int $effectif): bool
function creneau_libre_groupe(array $planning, string $id_groupe, $creneau): bool
```

Le parametre `$creneau` est un tableau de la forme :

```php
[
    'jour' => 'Lundi',
    'debut' => '08:00',
    'fin' => '12:00'
]
```

Ces fonctions verifient respectivement :

- qu'une salle n'a pas deja une affectation sur le meme creneau ;
- que la capacite de la salle est superieure ou egale a l'effectif du groupe ;
- qu'un groupe n'a pas deja un cours sur le meme creneau.

## Q7. Generation du planning

La fonction principale est :

```php
function generer_planning(
    ?array $salles = null,
    ?array $promotions = null,
    ?array $cours = null,
    ?array $options = null,
    ?array $creneaux_disponibles = null
): array
```

Strategie retenue :

1. Les salles sont triees par capacite croissante.
2. Pour chaque cours, le systeme determine le groupe concerne :
   tronc commun pour toute la promotion, ou option pour un groupe specifique.
3. Le systeme parcourt les creneaux disponibles du lundi au vendredi.
4. Pour chaque creneau, il choisit la premiere salle libre dont la capacite convient.
5. L'affectation est ajoutee seulement si la salle et le groupe sont libres.

Cette strategie limite la sous-exploitation des grandes salles, car les petits groupes sont d'abord places dans les plus petites salles suffisantes.

## Q8. Sauvegarde du planning

La fonction de sauvegarde est :

```php
function sauvegarder_planning(array $planning, ?string $chemin_fichier = null): bool
```

Si le fichier cible se termine par `.txt`, le planning est sauvegarde au format texte structure :

```txt
jour;debut;fin;salle;code_cours;groupe
Lundi;08:00;12:00;AUD-L1;1;PROMO:L1
Lundi;13:00;17:00;AUD-L2;2;PROMO:L2
```

Dans l'application, la generation sauvegarde maintenant deux fichiers :

- `data/planning.json`, pour le rechargement par l'application ;
- `data/planning.txt`, pour respecter le format demande dans Q8.
